<?php

/*
    206anyos.php: Tras leer la edad de una persona, 
    mostrar la edad que tendrá dentro de 10 años y hace 10 años. 
    Además, muestra qué año será en cada uno de los casos. 
    Finalmente, muestra el año de jubilación suponiendo que trabajarás 
    hasta los 65 años. En este caso, no hace falta que previamente crees un formulario, 
    puedes probar el ejercicio via URL: 206anyos.php?edad=33.

*/
$edad = $_GET["edad"];
$anyoActual = date("Y");
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 206</title>

</head>

<body>
    <p>En diez años la persona tendrá <?= ($edad + 10) ?> años y el año será <?= ($anyoActual + 10) ?>. </p>
    <p>Hace diez años la persona tenía <?= ($edad - 10) ?> años y el año fue <?= ($anyoActual - 10) ?>.</p>
    <p>El año de jubilación será <?= ($anyoActual - $edad + 65) ?>.</p>
</body>

</html>